# Web Quality Gatekeeper Action Plan

## 1. Add meaningful alternative text

- **Source**: a11y
- **Severity**: critical
- **Why it matters**: Ensure &lt;img&gt; elements have alternative text or a role of none or presentation
- **Expected impact**: Lower accessibility violation counts and improved audit pass rate.
- **Evidence**:
  - Rule: image-alt
  - Impacted nodes: 1
  - WCAG tags: wcag2a, wcag111
- **Remediation steps**:
  - Add an \`alt\` attribute that communicates the image intent.
  - Use \`alt=""\` for decorative-only images to avoid noisy announcements.
- **Verification**:
  - Re-run WQG and confirm a11y violations decreased for this page.
  - Validate impacted elements with keyboard \+ screen reader spot checks.
