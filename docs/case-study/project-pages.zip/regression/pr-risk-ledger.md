# PR Risk Ledger

- Overall status: **FAIL**
- Highest severity: **critical**
- Risks: 3
- Report: `report.html`
- Summary: `summary.v2.json`

## CRITICAL - Add meaningful alternative text

- Source: a11y
- Affected surfaces: default \(https://project-pages.example/\)
- Recommended action: Add an \`alt\` attribute that communicates the image intent. Use \`alt=""\` for decorative-only images to avoid noisy announcements.
- Verification: Re-run WQG and confirm a11y violations decreased for this page. Validate impacted elements with keyboard \+ screen reader spot checks.
- Evidence:
  - Rule: image-alt
  - Impacted nodes: 1
  - WCAG tags: wcag2a, wcag111

## HIGH - Accessibility violations require triage

- Source: a11y
- Affected surfaces: default \(https://project-pages.example/\)
- Recommended action: Fix critical and serious accessibility issues first, then rerun the gate.
- Verification: Confirm the next summary reports zero blocking accessibility violations.
- Evidence:
  - A11y violations: 1

## HIGH - 1 audited page failed the gate

- Source: aggregate
- Affected surfaces: default \(https://project-pages.example/\)
- Recommended action: Review the failing page artifacts before merging.
- Verification: Open report.html and confirm each failed page has a matching remediation plan.
- Evidence:
  - Overall status: fail
  - Failed pages: 1/1
