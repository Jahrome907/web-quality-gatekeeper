# PR Risk Ledger

- Overall status: **PASS**
- Highest severity: **medium**
- Risks: 1
- Report: `report.html`
- Summary: `summary.v2.json`

## MEDIUM - Minify CSS

- Source: perf
- Affected surfaces: default \(https://project-pages.example/\)
- Recommended action: Apply the Lighthouse recommendation for this opportunity.
- Verification: Re-run WQG and verify Lighthouse opportunity savings are reduced. Confirm performance score and LCP trend improves over subsequent runs.
- Evidence:
  - Opportunity: unminified-css
  - Estimated savings: 0ms
  - Display value: Est savings of 5 KiB
